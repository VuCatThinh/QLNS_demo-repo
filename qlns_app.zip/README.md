# qlns_app

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

![trang chủ admin](image.png)
![trang quản lý nhân viên](image-1.png)
![thêm nhân viên](image-2.png)
![cập nhật nhân viên](image-3.png)
![quản lý chấm công](image-4.png)
![quản lý lương](image-5.png)
![thưởng/phạt](image-6.png)